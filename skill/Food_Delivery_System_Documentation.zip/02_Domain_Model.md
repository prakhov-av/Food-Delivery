# Доменная модель

Сущности: - User - Restaurant - Menu - MenuItem - Order - OrderItem

Связи: - Restaurant → Menu (1:1) - Menu → MenuItem (1:N) - Order →
Customer(User) - Order → Courier(User) - Order → Restaurant - OrderItem
→ Order - OrderItem → MenuItem
