# Архитектура

## Структура каждого модуля

-   Entity
-   DTO
-   Mapper
-   Repository
-   Service
-   Controller
-   Module

## Поток вызовов

Controller → Service → Repository → TypeORM → PostgreSQL

## Принципы

-   Repository отвечает только за работу с БД.
-   Service содержит бизнес-логику.
-   Controller принимает HTTP-запросы.
-   Mapper преобразует Entity ↔ DTO.
