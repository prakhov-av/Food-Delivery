# Журнал разработки

## Этап 1 --- Архитектура

-   ✔ Entity
-   ✔ DTO
-   ✔ Mapper
-   ✔ Repository
-   ✔ Service
-   ✔ Controller
-   ✔ Module
-   ✔ Swagger
-   ✔ PostgreSQL

Следующий этап: Валидация.
